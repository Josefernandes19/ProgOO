package hotelaula;

import hotelaula.Data;
import hotelaula.Hospede;
import hotelaula.Hotel;
import hotelaula.Quarto;
import java.util.ArrayList;


public class Teste {

    public static void main(String[] args) {        
     
        
       ArrayList<Data> arrayD = new ArrayList();
       Data a = new Data(21, 5, 2016);
       Data b = new Data(15, 5, 2016);
       arrayD.add(a);
       arrayD.add(b);
       
       ArrayList<Hospede> arrayH = new ArrayList();
       Hospede c = new Hospede("Zé", "Goiaba", arrayD.get(0));
       Hospede d = new Hospede("Jair", "Creissu", arrayD.get(1));
       arrayH.add(c);
       arrayH.add(d);
       
       ArrayList<Quarto> arrayQ = new ArrayList();
       Quarto e = new Quarto(157, 3, true);
       Quarto f = new Quarto(2, 1, false);
       Quarto g = new Quarto(300, 2, true);
       arrayQ.add(e);
       arrayQ.add(f);
       arrayQ.add(g);
       
       
       
       Hotel hot = new Hotel("UNIFAL", arrayH, arrayQ);
       hot.ocuparQuarto(arrayQ.get(1));
       hot.ocuparQuarto(arrayQ.get(0));
       
       hot.exibeDados();
       
       hot.listarHospedes();
       
       hot.exibeQuartos();
        
        
        
        
    }
}
