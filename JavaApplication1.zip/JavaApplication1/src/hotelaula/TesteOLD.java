/* Data d = new Data(10,10,2000);
        Hospede h2 = new Hospede("José", "Silva", d);
        h2.mostraHospede();
        
        Data d2 = new Data(10,10,2003);
        Hospede h3 = new Hospede("José", "Silva", d2);
        h3.mostraHospede();
        
        int[] telefones = new int[10];
        telefones[0] = 33521212;
        //CRIAR ARRAY DE HOSPEDES!
        Hospede[] arrayDeHospedes = new Hospede[3];
        arrayDeHospedes[0] = new Hospede("Daniel", "Torrico", d2);
        arrayDeHospedes[1] = new Hospede("Maria", "Creuza", d2);
        arrayDeHospedes[2] = new Hospede("Camila", "Silva", d2);
        
        //Criar array de quartos
        Quarto[] arrayDeQuartos = new Quarto[4];
        arrayDeQuartos[0] = new Quarto(0, 1, false, false);
        arrayDeQuartos[2] = new Quarto(1, 1, false, true);
        arrayDeQuartos[3] = new Quarto(2, 2, false, false);
        arrayDeQuartos[4] = new Quarto(3, 2, false, true);
        
        Hotel hotel = new Hotel("Hotel BCC", arrayDeHospedes, arrayDeQuartos, telefones); */