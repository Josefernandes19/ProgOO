package hotelaula;

public class Hotel {
    private String nome;
    private Hospede[] arrayDeHospedes;
    private Quarto[] arrayDeQuartos;
    private int[] telefones;
    
    public Hotel(){
        
    }
    public Hotel(String nome, Hospede[] arrayDeHospedes, Quarto[] arrayDeQuartos, int[] telefones){
        this.nome = nome;
        this.arrayDeHospedes = arrayDeHospedes;
        this.arrayDeQuartos = arrayDeQuartos;
        this.telefones = telefones;
    }

    public Hotel(String nome, Hospede[] arrayDeHospedes, Quarto[] arrayDeQuartos) {
        this.nome = nome;
        this.arrayDeHospedes = arrayDeHospedes;
        this.arrayDeQuartos = arrayDeQuartos;
    }
    
    
    
    public int quartosLivres(){
        int fr = 0;
        for (Quarto x : arrayDeQuartos)
        {
            if (x.livre() == true)
            {
                fr++;
            }
        }
        
        return fr;
    }
    
    public int hospedesAlocados(){
        int al = 0;
        for (Hospede h : arrayDeHospedes)
        {
            al++;
        }
        
        return al;
    }
    
    public void exibeDados(){
        int i;
        
        System.out.println("Hotel: " + this.nome);
        i = quartosLivres();
        System.out.println("Quantidade de quartos livres: " + i);
        i = hospedesAlocados();
        System.out.println("Total de hóspedes alocados: " + i);
        System.out.println(" ");
    }
    
    public void ocuparQuarto(Quarto q){
        q.setOcp();
    }
    
    public void descocuparQuarto(Quarto q){
        q.setDsc();
    }
    
    public void exibeQuartos(){
        for (Quarto x : arrayDeQuartos)
        {
            if (x.livre())
                System.out.println(x.getNum());
        }
    }
    
    public void listarHospedes(){
        int i = 0;
        for (Hospede h : arrayDeHospedes)
        {
            i++;
            System.out.println("Hospede " + i + ": " + h.getNome() + " " + h.getSobrenome());
        }
        System.out.println(" ");
    }
}
