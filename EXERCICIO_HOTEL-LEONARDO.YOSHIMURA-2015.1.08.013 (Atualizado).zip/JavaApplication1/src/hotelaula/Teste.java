package hotelaula;

import hotelaula.Data;
import hotelaula.Hospede;
import hotelaula.Hotel;
import hotelaula.Quarto;


public class Teste {

    public static void main(String[] args) {        
     
        
       Data[] arrayD = new Data[2];
       arrayD[0] = new Data(21, 5, 2016);
       arrayD[1] = new Data(15, 5, 2016);
       
       Hospede[] arrayH = new Hospede[2];
       arrayH[0] = new Hospede("Zé", "Goiaba", arrayD[0]);
       arrayH[1] = new Hospede("Jair", "Creissu", arrayD[1]);
       
       Quarto[] arrayQ = new Quarto[3];
       arrayQ[0] = new Quarto(157, 3, true);
       arrayQ[1] = new Quarto(2, 1, false);
       arrayQ[2] = new Quarto(300, 2, true);
       
       
       Hotel hot = new Hotel("UNIFAL", arrayH, arrayQ);
       hot.ocuparQuarto(arrayQ[1]);
       hot.ocuparQuarto(arrayQ[0]);
       
       hot.exibeDados();
       
       hot.listarHospedes();
       
       hot.exibeQuartos();
        
        
        
        
    }
}
