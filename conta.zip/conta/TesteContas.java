/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heranca.exercicio.conta;

/**
 *
 * @author Torrico
 */
public class TesteContas {
    private static final double SELIC = 0.01;
    public static void main(String[] args) {
        Conta c = new ContaCorrente(111);
        Conta cc = new ContaCorrente(222);
        Conta cp = new ContaPoupanca(333);
        Conta ci = new ContaInvestimento(444);
        c.deposita(1000);
        cc.deposita(1000);
        cp.deposita(1000);
        ci.deposita(1000);
        AtualizadorDeContas adc = new AtualizadorDeContas(SELIC);

        adc.roda(c);
        adc.roda(cc);
        adc.roda(cp);
        adc.roda(ci);

        System.out.println("Saldo Total: " + adc.getSaldoTotal());

    }
}
