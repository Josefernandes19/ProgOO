/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heranca.exercicio.conta;

/**
 *
 * @author Torrico
 */
public class ContaCorrente extends Conta {

    public ContaCorrente(int numero){
        super(numero);
    }
    
    @Override
    public void atualiza(double taxa) {
        this.saldo += this.saldo * taxa *2;
    }

    @Override
    public void deposita(double valor) {
        super.deposita(valor - 0.10);
    }
}
