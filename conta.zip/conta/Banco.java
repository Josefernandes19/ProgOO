/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heranca.exercicio.conta;

import java.util.ArrayList;

/**
 *
 * @author Torrico
 */
public class Banco {
    private ArrayList<Conta> listaContas = new ArrayList();
    
    public void adiciona(Conta c){
        this.listaContas.add(c);
    }
    
    public Conta pegaConta(int x){
        return this.listaContas.get(x);
    }
    
    public int pegaTotalContas(){
        return this.listaContas.size();
    }
}
