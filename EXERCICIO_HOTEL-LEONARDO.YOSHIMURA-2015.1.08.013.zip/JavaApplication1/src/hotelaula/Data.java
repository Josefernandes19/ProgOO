
package hotelaula;


public class Data {

    private int dia;
    private int mes;
    private int ano;
    
    public Data(){
        
    }
    public Data(int dia, int mes, int ano){
        if(dia>31){
            this.dia=0;
        }
        if(mes>12){
            this.mes=0;
        }
        this.ano = ano;
        if(dia==0 && mes==0 && ano == 0){
            System.out.println("Data Inválida !");
        }
    }
    
    public void mostraData() {
        if(this.dia==0){
            System.out.println("Dia inválido !");
        }
        if(this.mes==0){
            System.out.println("Mês inválido !");
        }
        System.out.println(this.dia + "/" + this.mes + "/" + this.ano);
    }

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        if (dia > 31) {
            this.dia = 0;
        } else {
            this.dia = dia;
        }
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        if (mes > 12) {
            this.mes = 0;
        } else {
            this.mes = mes;
        }
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

}
