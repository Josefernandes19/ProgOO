package hotelaula;


public class Quarto {
    private int numero, numeroDeCamas;
    private boolean isSuite, isLivre;

    public Quarto(int numero, int numeroDeCamas, boolean isSuite) {
        this.numero = numero;
        this.numeroDeCamas = numeroDeCamas;
        this.isSuite = isSuite;
    }
    
    
    
    public boolean livre(){
        return this.isLivre;
    }
    
    public void setOcp(){
        this.isLivre = false;
    }
    
    public void setDsc(){
        this.isLivre = true;
    }
    
    public int getNum(){
        return this.numero;
    }
}
