package hotelaula;


public class Hospede {
    private static int contador = 0;
    private int id;
    private String nome;
    private String sobrenome;
    private Data dataEntrada;

    public Hospede(){
        this.id = ++contador;
        this.dataEntrada = new Data();
       //Para que toda vez que seja criado um hóspede, já seja reservado na memória um espaço para data
    }
    public Hospede(String nome, String sobrenome, int dia, int mes, int ano){
        this.id = ++contador;
        this.dataEntrada = new Data();
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.dataEntrada.setDia(dia);
        this.dataEntrada.setMes(mes);
        this.dataEntrada.setAno(ano);
    }
    public Hospede(String nome, String sobrenome, Data dataEntrada){
        this.id = ++contador;
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.dataEntrada = dataEntrada;
    }
    
    
    public void mostraHospede(){
        if(this.nome == null){
            System.out.println("Nome do hóspede: Não informado");
        }else{
            System.out.println("Nome do hóspede:"+this.getNome());
        }
        if(this.sobrenome == null){
            System.out.println("Sobrenome do hóspede: Não informado");
        }else{
            System.out.println("Sobrenome do hóspede:"+this.getSobrenome());
        }
        System.out.print("Data de entrada:");
        this.dataEntrada.mostraData();
    }
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }
    public void setDataDeEntrada(int dia, int mes, int ano){
        this.dataEntrada.setDia(dia);
        this.dataEntrada.setMes(mes);
        this.dataEntrada.setAno(ano);
    }
    
    public Data getDataDeEntrada(){
        return dataEntrada;
    }
    
}
